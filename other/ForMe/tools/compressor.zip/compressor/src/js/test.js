//压缩测试文件
var str1="1";
var str2="2";
var str3="3";
var str4="4";
var str5="5";
alert(str1)
alert(str2)
alert(str3)
alert(str4)
alert(str5)