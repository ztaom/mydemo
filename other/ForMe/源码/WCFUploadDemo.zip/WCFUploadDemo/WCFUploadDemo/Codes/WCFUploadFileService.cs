﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Collections.Generic;

using WCFUploadDemo.UploadServiceReference;

namespace WCFUploadDemo.Codes
{

        public class WCFUploadFileService : INotifyPropertyChanged
        {

            public class FileList : INotifyPropertyChanged
            {
                private void NotifyPropertyChanged(string info)
                {
                    if (PropertyChanged != null)
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs(info));
                    }
                }

                private int m_BufferSize = 4096;
                private FileInfo m_FileList;
                private UploadStatusType m_UploadStauts;
                private long m_BytesSent;
                private long m_BytesSentCount;
                private int m_SentPercentage;
                private string m_SavePath;
                private ObservableCollection<UploadLog> m_LOG = new ObservableCollection<UploadLog>();

                public enum UploadStatusType
                {
                    Waitting, Uploading, Completed, Failed, Pause
                }

                /// <summary>
                /// 每次上传的字节数。应在给File赋值前设定。
                /// </summary>
                public int BufferSize
                {
                    get
                    {
                        return m_BufferSize;
                    }
                    set
                    {
                        m_BufferSize = value;
                    }
                }

                public class UploadLog
                {
                    public UploadLog(DateTime time, string context, object tag)
                    {
                        LogTime = time;
                        LogContext = context;
                        Tag = tag;
                    }

                    public DateTime LogTime { get; set; }
                    public string LogContext { get; set; }
                    public object Tag { get; set; }
                }

                /// <summary>
                /// 上传日志
                /// </summary>
                public ObservableCollection<UploadLog> LOG
                {
                    get
                    {
                        return m_LOG;
                    }
                    set
                    {
                        m_LOG = value;
                        NotifyPropertyChanged("LOG");
                    }
                }

                private void AddLog(UploadLog log)
                {
                    LOG.Add(log);
                }

                /// <summary>
                /// 等待传输的字节数据列表。设计this.File时自动赋值，按BufferSize读取至Byte[]等待上传。
                /// </summary>
                public List<Byte[]> FileContext { get; set; }

                /// <summary>
                /// 要上传的文件
                /// </summary>
                public FileInfo File
                {
                    get { return m_FileList; }
                    set
                    {
                        m_FileList = value;
                        Stream soureFile = null;
                        UploadStatus = UploadStatusType.Waitting;
                        try
                        {
                            soureFile = value.OpenRead();
                        }
                        catch (Exception)
                        {
                            UploadStatus = UploadStatusType.Failed;
                            AddLog(new UploadLog(DateTime.Now, "无法读取文件", null));
                        }
                        long BytesCount = soureFile.Length;
                        long BytesRead = 0;
                        if (FileContext == null)
                        {
                            FileContext = new List<byte[]>();
                        }
                        else
                        {
                            FileContext.Clear();
                        }
                        long ReadSize = BufferSize;
                        while (BytesRead < BytesCount)
                        {
                            if (BytesRead + BufferSize > BytesCount) //调整最后一个文件块的大小
                            {
                                ReadSize = BytesCount - BytesRead;
                            }
                            byte[] bytes = new byte[ReadSize];
                            BytesRead += soureFile.Read(bytes, 0, bytes.Length);
                            FileContext.Add(bytes);
                        }
                        soureFile.Close();
                        soureFile.Dispose();
                        NotifyPropertyChanged("File");
                    }
                }

                /// <summary>
                /// 保存路径
                /// </summary>
                public string SavePath
                {
                    get { return m_SavePath; }
                    set { m_SavePath = value; NotifyPropertyChanged("SavePath"); }
                }

                /// <summary>
                /// 上传状态
                /// </summary>
                public UploadStatusType UploadStatus
                {
                    get { return m_UploadStauts; }
                    set { m_UploadStauts = value; NotifyPropertyChanged("UploadStatus"); }
                }
                /// <summary>
                /// 本次上传字节
                /// </summary>
                public long BytesSent
                {
                    get { return m_BytesSent; }
                    set { m_BytesSent = value; NotifyPropertyChanged("BytesSent"); }
                }
                /// <summary>
                /// 已上传字节
                /// </summary>
                public long BytesSentCount
                {
                    get { return m_BytesSentCount; }
                    set { m_BytesSentCount = value; NotifyPropertyChanged("BytesSentCount"); }
                }
                /// <summary>
                /// 已上传比率
                /// </summary>
                public int SentPercentage
                {
                    get { return m_SentPercentage; }
                    set { m_SentPercentage = value; NotifyPropertyChanged("SentPercentage"); }
                }

                #region INotifyPropertyChanged 成员

                public event PropertyChangedEventHandler PropertyChanged;

                #endregion
            }

            UploadFileServiceClient uploadClient = new UploadFileServiceClient();

            public WCFUploadFileService()
            {
                uploadClient.BeginUploadCompleted += new EventHandler<AsyncCompletedEventArgs>(uploadClient_BeginUploadCompleted);
            }

            void uploadClient_BeginUploadCompleted(object sender, AsyncCompletedEventArgs e)
            {
                bool beginNew = false; //是开始一个新文件或续传
                if (e.Error != null)
                {
                    Files[CurrentFileIndex].UploadStatus = FileList.UploadStatusType.Failed;
                    Files[CurrentFileIndex].LOG.Add(new FileList.UploadLog(DateTime.Now, e.Error.Message, null));
                    CurrentFileIndex++;
                    CurrentFileContextIndex = 0;
                    beginNew = true;
                }
                else
                {
                    Files[CurrentFileIndex].BytesSent = Files[CurrentFileIndex].FileContext[CurrentFileContextIndex].Length;
                    Files[CurrentFileIndex].BytesSentCount += Files[CurrentFileIndex].BytesSent;
                    Files[CurrentFileIndex].SentPercentage = Convert.ToInt32((double)Files[CurrentFileIndex].BytesSentCount / (double)Files[CurrentFileIndex].File.Length * 100);
                    if (CurrentFileIndex < Files.Count)
                    {
                        if (CurrentFileContextIndex < Files[CurrentFileIndex].FileContext.Count - 1)
                        {
                            CurrentFileContextIndex++;
                        }
                        else
                        {
                            Files[CurrentFileIndex].UploadStatus = FileList.UploadStatusType.Completed;
                            CurrentFileIndex++;
                            CurrentFileContextIndex = 0;
                            beginNew = true;
                        }
                    }
                }
                if (CurrentFileIndex < Files.Count)
                {
                    Files[CurrentFileIndex].UploadStatus = FileList.UploadStatusType.Uploading;
                    uploadClient.BeginUploadAsync(Files[CurrentFileIndex].SavePath + "//"
                        + Files[CurrentFileIndex].File.Name + "."
                        + CurrentFileContextIndex.ToString().PadLeft(9, '0')
                        + "-" + Files[CurrentFileIndex].FileContext.Count,
                          Files[CurrentFileIndex].FileContext[CurrentFileContextIndex], beginNew);
                }
                else
                {
                    Files[CurrentFileIndex - 1].UploadStatus = FileList.UploadStatusType.Completed;
                }
            }

            private ObservableCollection<FileList> m_Files = new ObservableCollection<FileList>();

            /// <summary>
            /// 准备上传的文件列表
            /// </summary>
            public ObservableCollection<FileList> Files
            {
                get
                {
                    return m_Files;
                }
                set
                {
                    m_Files = value;
                    NotifyPropertyChanged("Files");
                }
            }

            /// <summary>
            /// 当前上传的文件索引
            /// </summary>
            private int CurrentFileIndex;
            /// <summary>
            /// 当前上传的文件块索引
            /// </summary>
            private int CurrentFileContextIndex;

            /// <summary>
            /// 开始上传。按BufferSize将文件分块，块命名规则为 filename.blockid-blockcount，服务器接收完最后一块后合并成源文件。
            /// </summary>
            public void BeginUpload()
            {
                if (Files.Count > 0)
                {
                    CurrentFileIndex = 0;
                    CurrentFileContextIndex = 0;
                    Files[CurrentFileIndex].UploadStatus = FileList.UploadStatusType.Uploading;
                    uploadClient.BeginUploadAsync(Files[CurrentFileIndex].SavePath + "//"
                        + Files[CurrentFileIndex].File.Name + "."
                        + CurrentFileContextIndex.ToString().PadLeft(9, '0')
                        + "-" + Files[CurrentFileIndex].FileContext.Count,
                          Files[CurrentFileIndex].FileContext[CurrentFileContextIndex], true);
                }
            }

            #region INotifyPropertyChanged 成员

            public event PropertyChangedEventHandler PropertyChanged;

            private void NotifyPropertyChanged(string info)
            {
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs(info));
                }
            }

            #endregion
        }

}
