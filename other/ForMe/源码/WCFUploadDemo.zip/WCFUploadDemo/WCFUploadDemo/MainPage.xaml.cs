﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WCFUploadDemo
{
    public partial class MainPage : UserControl
    {
        Codes.WCFUploadFileService upload = new Codes.WCFUploadFileService();

        public MainPage()
        {
            InitializeComponent();
            list_uploadlist.ItemsSource = upload.Files;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Multiselect = true;
            bool? result = file.ShowDialog();
            if (result.HasValue)
            {
                if (result.Value)
                {
                    upload.Files.Clear();
                    foreach (System.IO.FileInfo f in file.Files)
                    {
                        Codes.WCFUploadFileService.FileList filelist = new Codes.WCFUploadFileService.FileList();
                        filelist.SavePath = "20120222";
                        filelist.BufferSize = 1024 * 32;
                        filelist.File = f;
                        upload.Files.Add(filelist);
                    }

                    upload.BeginUpload();
                }
            }

        }
    }
}
