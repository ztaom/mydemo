﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.IO;

namespace WCFUploadDemo.Web
{
    [ServiceContract(Namespace = "")]
    [SilverlightFaultBehavior]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class UploadFileService
    {
        [OperationContract]
        public void DoWork()
        {
            // 在此处添加操作实现
            return;
        }

        // 在此处添加更多操作并使用 [OperationContract] 标记它们

        /// <summary>
        /// 开始上传
        /// </summary>
        /// <param name="FullPath">保存路径及文件名</param>
        /// <param name="FileContext">文件内容</param>
        /// <param name="Overwrite">是否覆盖</param>
        [OperationContract]
        public void BeginUpload(string FullPath, byte[] FileContext, bool Overwrite)
        {
            try
            {
                if (!FullPath.StartsWith("\\"))
                {
                    FullPath = "\\" + FullPath;
                }

                string defaultFolder = System.Web.Hosting.HostingEnvironment.MapPath("~/UploadFiles");
                string tempUploadFolder = System.Web.Hosting.HostingEnvironment.MapPath("~/TempUploadFolder");
                string SaveFolder = Path.GetDirectoryName(FullPath);
                string Filename = Path.GetFileName(FullPath);
                string BlockString = Path.GetExtension(Filename);
                string[] block = BlockString.Split('-');
                if (block.Length != 2)
                {
                    throw new Exception("系统不支持此操作");
                }
                int FilesIndex = Convert.ToInt32(block[0].Replace(".", ""));
                int FilesCount = Convert.ToInt32(block[1]);
                string tempFolder = tempUploadFolder + "\\" + Path.GetFileNameWithoutExtension(FullPath); //上传到临时文件夹 

                Directory.CreateDirectory(tempFolder);
                if (!Directory.Exists(defaultFolder + "\\" + SaveFolder))
                {
                    Directory.CreateDirectory(defaultFolder + "\\" + SaveFolder);
                }
                FileMode mode = FileMode.Create;
                if (!Overwrite)
                {
                    mode = FileMode.Append;
                }
                using (FileStream fs = new FileStream(tempFolder + "\\" + Filename, mode, FileAccess.Write))
                {
                    fs.Write(FileContext, 0, FileContext.Length);
                }
                if (FilesIndex == FilesCount - 1)//是否最后一块文件，如是则合并文件块得到完整文件
                {
                    string UploadFile = defaultFolder + "\\" + SaveFolder + "\\" + Path.GetFileNameWithoutExtension(FullPath);
                    string[] files = Directory.GetFiles(tempFolder);
                    using (FileStream sFile = new FileStream(UploadFile, FileMode.Create, FileAccess.Write))
                    {
                        foreach (string file in files)
                        {
                            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read))
                            {
                                byte[] context = new byte[fs.Length];
                                fs.Read(context, 0, context.Length);
                                sFile.Write(context, 0, context.Length);
                            }
                            File.Delete(file);
                        }
                    }
                    Directory.Delete(tempFolder);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return;
        }

    }
}
