
### Objective C

Sparkle MIT
MPLib Apache
JNWAnimatableWindow MIT
Rechability MIT
Touch JSON MIT
MyStyledView BSD
SSKeychain MIT
MAAttachedWindow BSD (by Matt Gemmell)
HyperlinkTextField MIT


### Python

Django BSD
boto MIT
markdown2 MIT
keyring PSF
MacFSEvents BSD
tornado Apache

### Ruby

execjs MIT
coffee-script-source MIT
coffee-script MIT
sass MIT