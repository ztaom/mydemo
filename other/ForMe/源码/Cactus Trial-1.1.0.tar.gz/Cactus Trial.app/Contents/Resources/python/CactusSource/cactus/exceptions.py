#coding:utf-8

class InvalidCredentials(Exception):
    """
    Raised when invalid credentials are used to connect.
    """
    pass