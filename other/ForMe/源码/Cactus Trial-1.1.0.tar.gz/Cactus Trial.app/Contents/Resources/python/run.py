#!/usr/bin/env python
# encoding: utf-8

import sys
import os
import utils
import logging

cleanSysPath = []

for path in sys.path:
    if not "cactus" in path.lower():
        cleanSysPath.append(path)

sys.path = cleanSysPath

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'vendor/packages.zip'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'vendor/'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'CactusSource'))

# Patch to not access stuff in /etc for sandbox
# Todo: add apache mimetype file in app bundle
import mimetypes
mimetypes.knownfiles = []

# Patch boto to be able to find the ca certs file
import boto.connection

boto.connection.DEFAULT_CA_CERTS_FILE = os.path.join(
	os.path.dirname(__file__), 'vendor/cacerts.txt')

from cactus import cli

if __name__ == "__main__":
	
	parentProcessId = os.environ.get("PARENT_PROCESS", None)
	
	if parentProcessId:
		utils.exitWithoutProcess(int(parentProcessId), interval=10)
	
	try:
		cli.main()

	except Exception, e:
		
		import sys
		import traceback

		# exc_type, exc_value, exc_traceback = sys.exc_info()
		lines = traceback.format_exception(*sys.exc_info())

		logging.critical("\n".join(lines))

	sys.exit()