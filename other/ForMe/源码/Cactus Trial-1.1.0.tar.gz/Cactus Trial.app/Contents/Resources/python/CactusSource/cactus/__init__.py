import socket
import logging

from cactus.site import Site

socket.setdefaulttimeout(5)