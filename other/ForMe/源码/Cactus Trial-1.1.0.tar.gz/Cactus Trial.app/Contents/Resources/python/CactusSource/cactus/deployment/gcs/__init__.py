#coding:utf-8

CACTUS_CLIENT_ID = "985227088845.apps.googleusercontent.com"
CACTUS_CLIENT_SECRET = "6PzihpbiC33TW-GIagIRH0t_"
CACTUS_REQUIRED_SCOPE = "https://www.googleapis.com/auth/devstorage.full_control"
LOCAL_REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"
