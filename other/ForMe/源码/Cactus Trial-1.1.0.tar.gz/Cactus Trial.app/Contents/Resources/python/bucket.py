#!/usr/bin/env python
# encoding: utf-8

import os
import sys
import socket

socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.settimeout(5)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'vendor/packages.zip'))

from boto.s3.connection import S3Connection

S3Succes = 0
S3InputError = 1
S3AuthError = 2
S3CreateError = 3
S3SignupError = 4
S3NameError = 5

def exit(status):
	print "S3 bucket result: %s" % status
	sys.exit(status)

def main():

	accessKey = os.environ.get("accessKey")
	secretKey = os.environ.get("secretKey")
	bucketName = os.environ.get("bucketName")

	if None in [accessKey, secretKey]:
		exit(S3InputError)
	
	conn = S3Connection(accessKey, secretKey)
	
	try:
		 buckets = conn.get_all_buckets()
	except Exception, e:
		 print e
	
		 if e.code == 'NotSignedUp':
			 exit(S3SignupError)
	
		 exit(S3AuthError)
	
	if bucketName:
	
		bucketNames = [b.name for b in buckets]
	
		if bucketName is not None:	
			if bucketName not in bucketNames:
				try:
					awsBucket = conn.create_bucket(bucketName)
					awsBucket.configure_website('index.html', 'error.html')
				except Exception, e:
					print "S3 Error"
					print e
					if hasattr(e, 'error_code'):
						if e.code == 'BucketAlreadyExists':
							exit(S3NameError)
				
					exit(S3CreateError)
	
	sys.exit(S3Succes)

if __name__ == '__main__':
	main()

