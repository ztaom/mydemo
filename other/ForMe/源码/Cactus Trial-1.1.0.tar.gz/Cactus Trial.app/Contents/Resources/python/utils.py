import os
import sys
import time
import threading

# import logging
# import logging.handlers
# 
# LOG_FILENAME = '/tmp/catus.log'
# 
# # Set up a specific logger with our desired output level
# logger = logging.getLogger('CactusLogger')
# logger.setLevel(logging.DEBUG)
# 
# # Add the log message handler to the logger
# handler = logging.handlers.RotatingFileHandler(LOG_FILENAME, maxBytes=1024, backupCount=5)
# logger.addHandler(handler)


# http://stackoverflow.com/questions/7647167/check-if-a-process-is-running-in-python

def isProcessRunning(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def exitWithoutProcess(pid, interval=1):
    
    def check():
        while isProcessRunning(pid):
            time.sleep(interval)
            
        os.kill(os.getpid(), 9)
    
    thread = threading.Thread(target=check)
    thread.daemon = True
    thread.start()
