Documentation
================
This folder contains documentation for ABPlayerHTML5. It is provided to aid 
development and deployment across different platforms for different uses.

Sometimes we will fail to cover some use case or fail to document some feature.
In such cases, please open a bug ticket so we know and fix the docs.

The documentation is currently being worked on so it is still incomplete.

文档
================
这个文件夹包含了ABPlayerHTML5的开发文档。我们提供此文档以辅助跨平台和语言的二次开发。你可以更改
ABPlayerHTML5使其符合各种用途。

有时我们会忘记给出一些功能的文档。请开Bug报告来提醒我们更新。

目前文档还在开发中，所以可能并不全面。
