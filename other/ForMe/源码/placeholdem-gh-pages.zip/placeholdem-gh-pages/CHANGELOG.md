# Changelog

#### v1.0.0 // 2014-02-12
- initial release

#### v0.0.3 // 2014-02-10
- restructure directories and files
- add gulpfile.js, package.json, and .gitignore
- now producing with SASS and minifying both CSS and JS

#### v0.0.2 // 2014-02-08
- restructure code
- more flexible init
- add requestAnimationFrame
- check for in flux animation to allow toggling mid animation

#### v0.0.1 // 2014-02-07
- initial development