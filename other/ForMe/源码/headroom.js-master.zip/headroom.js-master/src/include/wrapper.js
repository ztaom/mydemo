(function(global) {

  'use strict';

  //= ../Debouncer.js
  //= ../Headroom.js

  global.Headroom = Headroom;

}(this));