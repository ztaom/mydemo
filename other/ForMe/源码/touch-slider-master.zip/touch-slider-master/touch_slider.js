(function($, undefined){

	$.fn.touchSlider = function(){

		var parent = $(this),
		slider = parent.find('ul'),
		item = slider.find('li'),
		dot = null,
		num = item.length,
		index = 0;
		startX = 0,
		distance = 0,
		startPos = 0,
		w = window.innerWidth;

		var styleInit = function(){
			item.css({'width': w, 'display': 'block'});
			parent.css({'width': w, 'margin-left': 'auto', 'margin-right': 'auto', 'overflow-x': 'hidden', 'position': 'relative'});
			slider.css({'width': (num * w) + 'px', 'position': 'absolute', 'top': 0, 'left': 0});
		};

		var createDot = function(){
			var html = '<div class="slider-dot">'
			$.each(item, function(){
				html += '<i></i>';
			});
			html += '</div>';
			parent.append(html);
			dot = parent.find('.slider-dot i');
		};

		var setSliderPos= function(pos){
			slider.css({'transform': 'translateX('+ pos +'px)', '-webkit-transform': 'translateX('+ pos +'px)'});
		}

		var touchMoveHandler = function(event){
			event.preventDefault();
			if(startX === 0) return;
			var x = event.touches[0].clientX;
			distance = x - startX;

			pos = startPos + distance;
			setSliderPos(pos);
		}

		var touchStartHandler = function(event){
			startX = event.touches[0].clientX;
			slider.css({'transition': 'none'});
		};

		var touchEndHandler = function(event){
			if (distance === 0) return;
			slider.css({'transition': 'transform 200ms linear', '-webkit-transition': '-webkit-transform 200ms linear'});
			if(distance < -20){ // swipe left
				if(index < num - 1){
					startPos -= w;
					index++;
				};
			}else if(distance > 20){ // swipe right
				if(index > 0){
					startPos += w;
					index--;
				};
			};
			setSliderPos(startPos);
			dot.removeClass('current').eq(index).addClass('current');
			startX = 0;
		};

		createDot();
		styleInit();
		parent.on('touchstart', touchStartHandler).on('touchend', touchEndHandler).on('touchmove', touchMoveHandler);
	}

})(Zepto)