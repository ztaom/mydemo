Touch slider plugin for Zepto
============

A mobile page slider plugin for Zepto

Check demo file for more detail

To run the demo page, you can use the Chrome developer tools to emulate mobile devices

一个应用于移动页面滑动的 Zepto 插件

查看 demo 文件了解更多

如果要运行 demo 页面，你需要 Chrome 开发者工具来模拟移动设备


