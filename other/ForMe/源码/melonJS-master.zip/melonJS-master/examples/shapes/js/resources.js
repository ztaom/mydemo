game.resources = [

	/* Graphics. 
	 * @example
	 * {name: "example", type:"image", src: "data/img/example.png"},
	 */
	{name: "sprites",		type:"image",	src: "data/img/sprites.png"}
];
