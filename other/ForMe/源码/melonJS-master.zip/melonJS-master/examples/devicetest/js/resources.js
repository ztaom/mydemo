game.resources = [];
