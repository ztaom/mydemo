game.resources = [
  {
    name : 'texture',
    type : 'json',
    src : 'data/img/texture.json'
  },
  {
    name : 'texture',
    type : 'image',
    src : 'data/img/texture.png'
  }
];
