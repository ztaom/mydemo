//
//  Scene01.h
//  TheSeasons
//
//  Created by Tammy Coron on 9/13/13.
//  Copyright (c) 2013 Tammy Coron. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Scene01 : SKScene

@end
