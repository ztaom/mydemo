SpriteSpin jQuery Plugin
=====================================================
Spritespin is a jQuery plugin that is able to play sprite image animations.

It takes an array of images or a stiched sprite sheet and plays them frame by frame like a flip book.

The aim of this plugin is to provide a 360 degree view of some kind of product. There is no flash needed. Everything is done with javascript and the jQuery framework.

Requirements
=====
The only requirement is the jQuery core framework. The plugin is tested with
jQuery-1.4.2.

Usage
=====
Create a container on your site where you want the animation to show up:
    <div id="spritespin"/>
In your javascript fire the plugin on that container:
    $("#spritespin").spritespin([options]);

For more information visit http://spritespin.ginie.eu