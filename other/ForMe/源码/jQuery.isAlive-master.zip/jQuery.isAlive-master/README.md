jQuery.isAlive
==============

 - jQuery.isAlive is a jQuery plugin for complex animated sites like advanced parallax. It is fully compatible with IE7+ and all mobile platforms. Touch events are included.

 - jQuery.isAlive can be called for as many times as you want on your web page, is CSS3 compatible, is responsive and can be customize very easy.

 - jQuery.isAlive is free to use.

(c) 2013 George Cheteles
orbitdeintuneric@gmail.com
