bounce.js
=========

[bounce.js](http://bouncejs.com) is a tool for generating tasty CSS3 powered keyframe animations. **The JS library for generating dynamic animations is on its way! You can follow me ([@JoelBesada](https://twitter.com/joelbesada)) on Twitter for updates.**
