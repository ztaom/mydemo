user_pref("browser.shell.checkDefaultBrowser", false);
