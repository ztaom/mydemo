# RadiantScroller changelog

## 0.0.3 (08/01/2014)

* Reworked pagination and scrolling
* Added `radiantScroller(<number>)` API method
* Added `radiantScroller('by', <number>)` API method

## 0.0.2 (07/01/2014)

* Docs and links

## 0.0.1 (07/01/2014)

* Basic functionality.
* Next/previos API methods.