touch
=====

Touch is a small javascript object that enables touch events, such as: swipe left, swipe right, swipe up, swipe down,  pinch in, pinch out, tap and double tap on touch devices.

see the [demo](http://jsbin.com/adevit/1)
